import React from "react";

// Basic React example for the assignment.
// This component shows a reusable item card. The 3 pages currently use HTML files
// and JavaScript so the project stays beginner-friendly.
export default function App() {
  const exampleItem = {
    name: "Black Wallet",
    status: "Lost",
    category: "Wallet / ID Card",
    location: "University Library",
  };

  return (
    <article className="item-card">
      <div className="item-art">
        <span className="status-badge">{exampleItem.status}</span>
        <span aria-hidden="true">👛</span>
      </div>
      <div className="item-body">
        <p className="item-category">{exampleItem.category}</p>
        <h3>{exampleItem.name}</h3>
        <p className="item-meta">📍 {exampleItem.location}</p>
      </div>
    </article>
  );
}
