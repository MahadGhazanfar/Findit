FINDIT — SMART LOST & FOUND PORTAL
==================================

PROJECT PAGES
1. index.html  - Home page
2. report.html - Report Lost/Found Item form
3. items.html  - Browse, search and filter items

TECHNOLOGIES
- HTML
- CSS
- JavaScript
- Basic React example (App.jsx)

HOW TO RUN
1. Extract the ZIP file.
2. Open the FindIt folder in VS Code.
3. Open index.html in your browser, or use the VS Code Live Server extension.
4. Navigate between pages using the top menu.

FEATURES
- Responsive layout for desktop and mobile
- Sample lost/found listings
- Report form with basic required-field validation
- New reports are saved in browser localStorage
- Search by item name, location, category and description
- Filter listings by Lost/Found status and category

IMPORTANT NOTES
- This is a frontend assignment/demo. It does not use a backend or MongoDB.
- Reports are saved only in the current browser on the current device.
- Uploaded image files are not stored or displayed in this basic version.
- Contact details are shown only as form data in the demo; no messaging service is connected.
- App.jsx is a small standalone React component example. The 3 HTML pages do not mount React yet.
  To run React, create a React/Vite project and move the component into its src folder.
